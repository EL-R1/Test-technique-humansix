<?php
class config{
    const SERVEUR="localhost";
    const BASEDEDONNEES="orders";
    const UTILISATEUR="root";
    const MOTDEPASSE="";
}