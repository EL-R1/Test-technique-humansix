<?php function mon_footer()
{ ?>

    </main>
    </body>
    </html>

<?php }?>